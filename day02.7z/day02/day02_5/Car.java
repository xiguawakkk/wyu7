package day02_5;

public class Car extends Vehicle {
	public void identifyNumberOfWheels() {
		System.out.println("���ֳ�");
		
	}
	

}
