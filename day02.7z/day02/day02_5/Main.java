package day02_5;

public class Main {
	public static void main(String[] args) {
		Vehicle carF = new Car();
		Vehicle carT = new Motorbike();
		carF.identifyNumberOfWheels();
		carT.identifyNumberOfWheels();
		
	}
}
