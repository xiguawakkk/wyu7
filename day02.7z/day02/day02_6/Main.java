package day02_6;

public class Main {
	public static void main(String[] args) {
		Bike bike = new Bike();
		Bus bus = new Bus();
		bike.start();
		bike.stop();
		bus.start();
		bus.stop();
	}
}
