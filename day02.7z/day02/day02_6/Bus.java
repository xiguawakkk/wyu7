package day02_6;

public class Bus implements Vehicle {
	public void start() {
		System.out.println("Bus start!");
	}
	public void stop() {
		System.out.println("Bus stop!");
	}
}
