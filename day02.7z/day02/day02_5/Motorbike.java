package day02_5;

public class Motorbike extends Vehicle {
	public void identifyNumberOfWheels() {
		System.out.println("˫�ֳ�");
	}
}
